function convertNumber() {
    const input = document.getElementById("numberInput").value.trim();
    const fromBase = parseInt(document.getElementById("fromSystem").value);
    const toBase = parseInt(document.getElementById("toSystem").value);
    const output = document.getElementById("output");

    if (input === "") {
        output.textContent = "Please enter a value.";
        return;
    }

    let decimalValue = parseInt(input, fromBase);

    if (isNaN(decimalValue)) {
        output.textContent = "Invalid number for selected system.";
        return;
    }

    output.textContent = "Result: " + decimalValue.toString(toBase).toUpperCase();
}
